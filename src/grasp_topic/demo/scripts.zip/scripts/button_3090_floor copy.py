#!/usr/bin/env python3
import rospy
import cv2
import numpy as np
import time
import os
import pexpect
import json
from grasp_topic.msg import plan, camera, pose


plan_received = False
image_received = False
save_path = ''

# 创建一个节点
rospy.init_node('button_3090')

def run_command_with_input(command, input_text):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect_b.log', 'w')  # 用于调试
    try:
        child.expect('Please enter the button you want: ')
        child.sendline(input_text)
        child.expect(pexpect.EOF)
        stdout = child.before
        stderr = child.after  # 捕获 EOF 之后的输出
    except pexpect.EOF:
        stdout = child.before
        stderr = ''  # 处理 EOF 错误
    finally:
        child.logfile.close()
    return stdout, stderr

# 定义回调函数
def callback1(plan):
    global plan_received
    rospy.loginfo('Sub 1: plan received - %s', plan.actions)
    plan_received = True

def callback3(image):
    global image_received
    global save_path
    color = np.array(list(image.color), dtype=np.uint8).reshape(image.size)
    depth_npy = np.array(list(image.depth), dtype=np.uint16).reshape((image.size[0], image.size[1]))
    par_path = '/home/user/PTY/button'
    save_path = os.path.join(par_path, "out")
    if not os.path.exists(save_path):
        os.mkdir(save_path)
    cv2.imwrite(os.path.join(save_path, "rgb.png"), color)
    cv2.imwrite(os.path.join(save_path,"depth.png"), depth_npy)
    rospy.loginfo('Sub 3: image received & saved!')
    image_received = True


# 创建订阅者对象
sub1 = rospy.Subscriber('/plan', plan, callback1)
sub3 = rospy.Subscriber('/image', camera, callback3)

# 创建发布者对象
pub1 = rospy.Publisher('/plan', plan, queue_size=10)
pub2 = rospy.Publisher('/camera', camera, queue_size=10)
pub4 = rospy.Publisher('/button_pose', pose, queue_size=10)

# sub1 = rospy.Subscriber('/plan', plan, callback1)
# sub3 = rospy.Subscriber('/image', camera, callback3)
# pub1 = rospy.Publisher('/plan', plan, queue_size=10)
# pub2 = rospy.Publisher('/camera', camera, queue_size=10)
# pub4 = rospy.Publisher('/pose', pose, queue_size=10)

# 发布数据
while not rospy.is_shutdown():
    plan0 = plan()
    pub1.publish(plan0)
    if plan_received:
        image = camera()
        pub2.publish(image)
        rospy.loginfo('Pub 2: camera delivered!')
    if image_received:
        command = """
            source ~/miniconda3/etc/profile.d/conda.sh && 
            conda activate button && 
            cd /home/user/PTY/button && 
            python main_policy.py --button 8
        """
        input_text = 'press the third floor'
        stdout, stderr = run_command_with_input(command, input_text=input_text)
        print("Standard Output:", stdout)
        # print("Standard Error:", stderr)
    if os.path.exists(os.path.join(save_path, "button-pose.json")):
        with open(os.path.join(save_path, "button-pose.json"), 'r') as file:
            data = json.load(file)
        sar_pose = np.array(data, dtype=np.float32).flatten().tolist()
        pub4.publish(pose(sar_pose))
        rospy.loginfo('Pub 4: pose delivered!')
        with open(os.path.join(save_path, "button-pose.json"), 'w') as file:
            json.dump([], file)  # 写入空列表或其他适当空结构
    rospy.sleep(2)
