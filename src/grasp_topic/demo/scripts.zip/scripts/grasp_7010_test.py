import rospy
import cv2
import numpy as np
import pexpect
from grasp_topic.msg import plan, camera, pose


camera_received = False
img_msg = None
camera2base = []

# 创建一个节点
rospy.init_node('grasp_7010')

def run_command_with_inputs(command, input_prompts, input_texts, exit_input='e'):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect.log', 'w')  # Used for debugging
    try:
        for prompt, text in zip(input_prompts, input_texts):
            child.expect(prompt)
            child.sendline(text)
            if text == exit_input:
                print('######### end!')
                child.sendintr()   # ctrl+c
                break
        child.expect(pexpect.EOF)
        stdout = child.before
        stderr = child.after  # Capture output after EOF
    except pexpect.EOF:
        stdout = child.before
        stderr = ''  # Handle EOF error
    finally:
        child.logfile.close()
        child.close(force=True)
    return stdout, stderr

def deliver_image(img_file):
    global camera2base
    img_msg = camera()
    img = cv2.imread(img_file)
    img_msg.size = list(img.shape)
    size = img_msg.size[0]*img_msg.size[1]*img_msg.size[2]
    img_msg.color = img.reshape(size).tolist()
    depth_file = img_file.replace("color.png", "depth.npy")
    depth_npy = np.load(depth_file)
    img_msg.depth = depth_npy.flatten().tolist()
    pose_file = img_file.replace("color.png", "pose.txt")
    camera2base = np.loadtxt(pose_file, dtype=np.float32)
    return img_msg

def callback2(camera):
    global camera_received
    rospy.loginfo('Sub2: camera ready!')
    camera_received = True

def callback4(pose):
    rospy.loginfo('Sub4: pose received!')
    object2camera = np.array(pose.pose).reshape(4, 4)
    grasp_pose = camera2base @ object2camera
    np.savetxt('/home/user/PTY/grasp_pose.txt', grasp_pose)
    rospy.loginfo('pose saved!')

# 创建发布者对象
pub3 = rospy.Publisher('/image', camera, queue_size=10)

# 创建订阅者对象
sub2 = rospy.Subscriber('/camera', camera, callback2)
sub4 = rospy.Subscriber('/pose', pose, callback4)


rospy.wait_for_message("/camera", camera, timeout=None)
if camera_received:
    # command = """
    #     cd /home/user/catkin_ws && python collect_data_posed.py
    # """
    # input_prompts = [
    #     '请开始id: ',
    #     '保存s还是继续c: ',
    #     '保存s还是继续c: ',
    #     '保存s还是继续c: '
    # ]
    # input_texts = ['100', 'c', 's', 'e']
    # stdout, stderr = run_command_with_inputs(command, input_prompts=input_prompts, input_texts=input_texts)
    # print("Standard Output:", stdout)
    # print("Standard Error:", stderr)
    rospy.loginfo('image delivering...')
    img_msg = deliver_image('/home/user/PTY/2024_07_30_19_43_05/0100_color.png')
    # img_msg = deliver_image('/home/user/catkin_ws/Polaris/0100_color.png')
if img_msg:
    pub3.publish(img_msg)
    rospy.loginfo('Pub 3: image delivered!')
    rospy.sleep(1)
rospy.wait_for_message("/pose", pose, timeout=None)
