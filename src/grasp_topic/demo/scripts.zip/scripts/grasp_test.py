#!/usr/bin/env python

import rospy
from grasp_topic.msg import plan,status


class GraspingNode:
    def __init__(self):
        rospy.Subscriber('/plan', plan, self.grasp_callback)
        rospy.Subscriber('/nav', status, self.callback_1)
        self.grasp_pub = rospy.Publisher('/grasp', status, queue_size=10)
        self.tasks = None
        self.current_plan = None
        self.current_task_index = 0

    def grasp_callback(self, msg):
        self.tasks = msg.actions
        self.current_task_index = msg.current_task_index

    def callback_1(self,msg):
        self.status=msg
        self.status.nav_status=msg.nav_status
        self.status.grasp_status=msg.grasp_status #[false,false,fasle]，长度与子任务数目一致
        self.execute_task()


    def execute_task(self):
        if self.current_task_index < len(self.tasks) and not self.status.grasp_status[self.current_task_index]:
            if self.status.nav_status[self.current_task_index]:
                task = self.tasks[self.current_task_index]
                rospy.loginfo(f"Executing grasp task: {task}")

                # 在这里执行任务的代码，例如调用一个函数执行任务
                rospy.sleep(2)  # 模拟任务执行时间
                self.task_completed(task)
        else:
            rospy.loginfo("No more tasks to execute")

    def task_completed(self,task=None):
        ##这里根据task写你的grasp执行代码，要求执行成功才能继续执行下去
        # print("-------任务执行结束-------")
        self.status.grasp_status = [True if i == self.current_task_index else False for i in range(len(self.tasks))]  #赋值当前子任务index下的状态值为true
        # print(self.status_msg.status)
        self.grasp_pub.publish(self.status)  #发布状态值，给规划模块接收


if __name__ == '__main__':
    rospy.init_node('grasping_node')
    GraspingNode()
    rospy.spin()
