#!/usr/bin/env python
#coding=utf-8
import rospy
from grasp_topic.msg import camera_pose

def callback(camera_pose):
    rospy.loginfo('Listener: %d''s y is %d', camera_pose.x, camera_pose.y)

def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber('grasp_topic', camera_pose, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()


