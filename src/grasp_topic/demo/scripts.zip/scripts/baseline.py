#!/usr/bin/env python
import rospy
import pexpect
import numpy as np
import time
import os
import cv2
import json
from std_msgs.msg import String, Bool  # String用于发送计划，Bool用于接收确认
from grasp_topic.msg import plan, camera, pose

def run_command_with_input(command, input_text):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect.log', 'w')  # 用于调试
    try:
        child.expect('Please enter the object you want: ')
        child.sendline(input_text)
        child.expect(pexpect.EOF)
        stdout = child.before
        stderr = child.after  # 捕获 EOF 之后的输出
    except pexpect.EOF:
        stdout = child.before
        stderr = ''  # 处理 EOF 错误
    finally:
        
        child.logfile.close()
    return stdout, stderr

class SequentialPlanPublisher:
    def __init__(self):
        print('initializing publisher')
        rospy.init_node('sequential_plan_publisher')
        
        # 发布者 - 发送计划
        self.plan_pub = rospy.Publisher('/plan', String, queue_size=10)
        self.pick_pose_pub = rospy.Publisher('/pose', pose, queue_size=10)
        # 订阅者 - 接收确认
        rospy.Subscriber('/plan_ack', Bool, self.ack_callback)
        
        # 预设的消息序列
        self.plans = None  # 可替换为实际计划
        self.current_plan_index = 0
        self.waiting_for_ack = False

        self.current_time = None
        self.polaris_ws = '/home/user/PTY/Polaris/SAR-Net++/pipeline'
        self.yolo_ws = ''
        
        # 等待订阅者连接
        while self.plan_pub.get_num_connections() < 1:
            rospy.loginfo("Waiting for subscriber to connect...")
            rospy.sleep(0.5)
        print('publisher initialized')

    def set_plans(self, plans):
        self.plans = plans
        print('plans set')

    def reset(self):
        self.plans = None  # 可替换为实际计划
        self.current_plan_index = 0
        self.waiting_for_ack = False

    def ack_callback(self, msg):
        """接收确认回调函数"""
        if msg.data and self.waiting_for_ack:
            rospy.loginfo("Received acknowledgement for plan %d", self.current_plan_index)
            self.waiting_for_ack = False
            self.current_plan_index += 1
            
            if self.current_plan_index < len(self.plans):
                rospy.sleep(1.0)  # 短暂延迟后发送下一条
                self.send_next_plan()
            else:
                rospy.loginfo("All plans sent successfully!")
                rospy.signal_shutdown("Mission complete")

    def send_next_plan(self, error_recovery=False):
        """发送下一条计划"""
        if self.current_plan_index < len(self.plans):
            plan_msg = self.plans[self.current_plan_index]
            if "observe" in plan_msg:
                self.sub_image = rospy.Subscriber('/image', camera, self.observe_call_back)
            elif "pick" in plan_msg or "place" in plan_msg:
                save_path = os.path.join(self.polaris_ws, "out", self.current_time)
                while not os.path.exists(os.path.join(save_path, "sar-pose.json")):
                    print("Pose not valid yet")
                    rospy.sleep(0.1)
                if os.path.exists(os.path.join(save_path, "sar-pose.json")):
                    with open(os.path.join(save_path, "sar-pose.json"), 'r') as file:
                        data = json.load(file)
                    sar_pose = np.array(data['pose'][0], dtype=np.float32).flatten().tolist()
                    print(pose(sar_pose))
                    self.pick_pose_pub.publish(pose(sar_pose))
                    rospy.loginfo('pick_pose_pub: pose delivered!')
                else:
                    print("ERROR: no valid pose")
                    # TODO error recovery
                    # self.current_plan_index -= 1
                    # self.send_next_plan(error_recovery=True)
            elif "push" in plan_msg:
                pass
            if error_recovery:
                plan_msg = plan_msg + " (error recovery)"
            rospy.loginfo("Sending plan %d: %s", self.current_plan_index+1, plan_msg)
            self.plan_pub.publish(plan_msg)
            self.waiting_for_ack = True
        else:
            rospy.loginfo("No more plans to send")

    def observe_call_back(self, image):
        if "push" in self.plans[self.current_plan_index + 1]:
            ws_path = self.yolo_ws
        else:
            ws_path = self.polaris_ws
        color = np.array(list(image.color), dtype=np.uint8).reshape(image.size)
        depth_npy = np.array(list(image.depth), dtype=np.uint16).reshape((image.size[0], image.size[1]))
        self.current_time = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        save_path = os.path.join(ws_path, "out", self.current_time)
        record_timestamps_path = os.path.join(ws_path, "out", "record_timestamps.txt")
        with open(record_timestamps_path, "a") as file:
            file.write(self.current_time + "\n")
        os.mkdir(save_path)
        os.mkdir(os.path.join(save_path, "color"))
        os.mkdir(os.path.join(save_path, "depth"))
        cv2.imwrite(os.path.join(save_path, "color", "0.png"), color)
        np.save(os.path.join(save_path, "depth", "0"), depth_npy)
        cv2.imwrite(os.path.join(save_path, "depth", "0.png"), depth_npy)
        rospy.loginfo('Image Sub: image received & saved!')

        self.estimate_after_observe()

        self.sub_image.unregister()

    def estimate_after_observe(self):
        if 'elevator' in self.plans[self.current_plan_index + 1]:
            # TODO
            pass
        else:
            command = """
            source ~/miniconda3/etc/profile.d/conda.sh && 
            conda activate polaris && 
            cd /home/user/PTY/Polaris/SAR-Net++/pipeline/EfficientSAM && 
            python grounded_light_hqsam.py && 
            cd ../SAR-Net/ && 
            python inference.py --config ./config_evaluate/nocs_real_mrcnn_mask.txt
            """
            obj = self.plans[self.current_plan_index].split(':')[-1]
            input_text = 'pick up the' + obj
            stdout, stderr = run_command_with_input(command, input_text=input_text)
            print("Standard Output:", stdout)


if __name__ == '__main__':
    try:
        spp = SequentialPlanPublisher()

        """
        Deliver the coffee cup from counter to plate at the table.
        """
        plans = [
                "go to: test table",
                "observe: white bottle",
                "pick: white bottle",
                "go to: center table",
                # "go to: elevator",
                # "elevator operation: floor 2",
                # "go to: room 202",
                # "observe: plate",
                "place: plate"]
        spp.set_plans(plans)
        spp.send_next_plan()
        rospy.spin()

    except rospy.ROSInterruptException:
        pass