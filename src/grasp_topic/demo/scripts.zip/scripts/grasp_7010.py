import rospy
import cv2
import numpy as np
import os
import pexpect
import signal
import concurrent.futures
from pty_connect.msg import camera, pose


img_msg = None
camera2base = []

# 创建一个节点
rospy.init_node('grasp_7010')

def run_command(command):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect.log', 'w')  # 用于调试
    try:
        child.expect(pexpect.EOF, timeout=90)
    except pexpect.exceptions.TIMEOUT:
        print(f"Timeout: {command} did not finish in time.")
    stdout = child.before
    stderr = child.after  # 捕获 EOF 之后的输出
    return child  # 返回 child 对象用于后续终止

def run_command_with_inputs(command, input_prompts, input_texts, exit_input='e'):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect.log', 'w')  # Used for debugging
    try:
        for prompt, text in zip(input_prompts, input_texts):
            child.expect(prompt)
            child.sendline(text)
            if text == exit_input:
                print('######### realsense data collected!')
                child.sendintr()   # ctrl+c
                break
        child.expect(pexpect.EOF)
        stdout = child.before
        stderr = child.after  # Capture output after EOF
    except pexpect.EOF:
        stdout = child.before
        stderr = ''  # Handle EOF error
    finally:
        child.logfile.close()
        child.close(force=True)
    return stdout, stderr

def terminate_process(child):
    """精确终止进程"""
    try:
        os.kill(child.pid, signal.SIGKILL)
        # os.kill(child.pid, signal.SIGTERM)  # 发送 SIGTERM 信号终止进程
        print(f"Process {child.pid} terminated.")
    except ProcessLookupError:
        print(f"Process {child.pid} does not exist.")

def deliver_image(img_file):
    global camera2base
    img_msg = camera()
    img = cv2.imread(img_file)
    img_msg.size = list(img.shape)
    size = img_msg.size[0]*img_msg.size[1]*img_msg.size[2]
    img_msg.color = img.reshape(size).tolist()
    depth_file = img_file.replace("color.png", "depth.npy")
    depth_npy = np.load(depth_file)
    img_msg.depth = depth_npy.flatten().tolist()
    pose_file = img_file.replace("color.png", "pose.txt")
    camera2base = np.loadtxt(pose_file, dtype=np.float32)
    return img_msg

def callback2(camera):
    rospy.loginfo('Sub 2: camera ready!')
    rospy.sleep(1)

def callback4(pose):
    global camera2base, img_msg
    rospy.loginfo('Sub 4: pose received!')
    object2camera = np.array(pose.pose).reshape(4, 4)
    grasp_pose = camera2base @ object2camera
    np.savetxt('/home/user/catkin_ws/grasp_pose.txt', grasp_pose)
    rospy.loginfo('pose saved!')
    img_msg = None
    

if __name__ == '__main__':
    while not rospy.is_shutdown():
        pub3 = rospy.Publisher('/image', camera, queue_size=10)
        sub2 = rospy.Subscriber('/camera', camera, callback2)

        rospy.wait_for_message("/camera", camera, timeout=None)

        command = """
            cd /home/user/catkin_ws && python collect_data_posed.py
        """
        commands = [
            "cd /home/user/calibration_ws && source devel/setup.bash && roslaunch panda_moveit_config franka_control.launch robot_ip:=172.16.0.2 load_gripper:=true",
            "cd /home/user/calibration_ws && source devel/setup.bash && roslaunch realsense2_camera rs_camera.launch align_depth:=true",
            "cd /home/user/calibration_ws && source devel/setup.bash && roslaunch easy_handeye publish.launch eye_on_hand:=true",
            "cd /home/user/catkin_ws && python collect_data_posed.py"
        ]
        input_prompts = [
            '请开始id: ',
            '保存s还是继续c: ',
            '保存s还是继续c: ',
            '保存s还是继续c: '
        ]
        input_texts = ['100', 'c', 's', 'e']

        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = []
            for command in commands[:-1]:  # 最后一个命令是交互式的
                print("##### DO...")
                # futures.append(run_command(command))
                futures.append(executor.submit(run_command, command))
                print("##### DONE...")
            futures.append(executor.submit(run_command_with_inputs, commands[-1], input_prompts, input_texts, 'e'))

            # 等待所有命令完成
            stdout, stderr = futures[-1].result()
            print("Standard Output:", stdout)
            print("Standard Error:", stderr)
            for future in futures[:-1]:  # 不包括第四个命令本身
                print('### KILLING...: ', future)
                # terminate_process(future)
                try:
                    result = future.result(timeout=5)  # 设置超时为5秒
                except concurrent.futures.TimeoutError:
                    print("Task did not complete in time, attempting to terminate...")
                    # 强制终止进程
                    for proc in executor._processes.values():
                        if proc.is_alive():
                            proc.terminate()
                            print(f"Process {proc.pid} terminated.")
                print('### KILLED...')
        print("##### All commands executed.")

        rospy.loginfo('image delivering...')
        # img_msg = deliver_image('/home/user/PTY/2024_07_30_19_43_05/0100_color.png')
        data_path = '/home/user/catkin_ws/Polaris'
        img_msg = deliver_image(os.path.join(data_path,'0100_color.png'))
        pub3.publish(img_msg)
        rospy.loginfo('Pub 3: image delivered!')
        os.remove(os.path.join(data_path,'0100_color.png'))
        os.remove(os.path.join(data_path,'0100_depth.npy'))
        os.remove(os.path.join(data_path,'0100_pose.txt'))

        sub4 = rospy.Subscriber('/pose', pose, callback4)
        rospy.wait_for_message("/pose", pose, timeout=None)
        camera2base = []
        print("-------任务执行结束-------")
        rospy.sleep(2)