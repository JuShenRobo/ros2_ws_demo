import rospy
import cv2
import numpy as np
import time
import os
import pexpect
import json
from grasp_topic.msg import plan, camera, pose, status, success


class GraspingNode:
    def __init__(self):
        self.plan_list = plan()
        rospy.Subscriber('/plan', plan, self.callback_plan)
        rospy.Subscriber('/nav', status, self.callback_nav)
        self.grasp_pub = rospy.Publisher('/grasp', status, queue_size=10)
        self.tasks = None
        self.current_plan = None
        self.current_task_index = 0

        self.pub1 = rospy.Publisher('/plan_list', plan, queue_size=10)
        self.sub3 = rospy.Subscriber('/image', camera, self.callback3)
        self.pub2 = rospy.Publisher('/camera', camera, queue_size=10)
        self.pub4 = rospy.Publisher('/pose', pose, queue_size=10)
        self.sub5 = rospy.Subscriber('/success', success, self.callback5)

    def polaris(self, image, input_text):
        color = np.array(list(image.color), dtype=np.uint8).reshape(image.size)
        depth_npy = np.array(list(image.depth), dtype=np.uint16).reshape((image.size[0], image.size[1]))
        par_path = '/home/user/PTY/Polaris/SAR-Net++/pipeline'
        current_time = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
        save_path = os.path.join(par_path, "out", current_time)
        record_timestamps_path = os.path.join(par_path, "out", "record_timestamps.txt")
        with open(record_timestamps_path, "a") as file:
            file.write(current_time + "\n")
        os.mkdir(save_path)
        os.mkdir(os.path.join(save_path, "color"))
        os.mkdir(os.path.join(save_path, "depth"))
        cv2.imwrite(os.path.join(save_path, "color", "0.png"), color)
        np.save(os.path.join(save_path, "depth", "0"), depth_npy)
        cv2.imwrite(os.path.join(save_path, "depth", "0.png"), depth_npy)
        rospy.loginfo('Sub 3: image received & saved!')
        if not os.path.exists(os.path.join(save_path, "grounded_light_hqsam")):
            rospy.loginfo("Polaris...")
            command = """
                source ~/miniconda3/etc/profile.d/conda.sh && 
                conda activate polaris && 
                cd /home/user/PTY/Polaris/SAR-Net++/pipeline/EfficientSAM && 
                python grounded_light_hqsam.py && 
                cd ../SAR-Net/ && 
                python inference.py --config ./config_evaluate/nocs_real_mrcnn_mask.txt
            """
            stdout, stderr = self.run_command_with_input(command, input_text=input_text)
            print("Standard Output:", stdout)
            # print("Standard Error:", stderr)

            if os.path.exists(os.path.join(save_path, "sar-pose.json")):
                with open(os.path.join(save_path, "sar-pose.json"), 'r') as file:
                    data = json.load(file)
                sar_pose = np.array(data['pose'][0], dtype=np.float32).flatten().tolist()
                self.pub4.publish(pose(sar_pose))
                rospy.loginfo('Pub 4: pose delivered!')
            rospy.sleep(2)

    def callback_plan(self, msg):
        self.tasks = msg.actions
        self.current_plan = msg.actions[msg.current_task_index]
        self.current_task_index = msg.current_task_index
        self.plan_list = msg
        rospy.loginfo('Sub 1: plan received - %s', msg.actions[msg.current_task_index])

    def callback_nav(self,msg):
        self.status=msg
        self.status.nav_status=msg.nav_status
        self.status.grasp_status=msg.grasp_status #[false,false,fasle]，长度与子任务数目一致
        self.execute_task()
        
    def callback3(self,image):
        input_text = self.current_plan
        self.polaris(image, input_text)

    def callback5(self,success):
        rospy.loginfo('Sub 5: 7010 completed!')

    def execute_task(self):
        if self.current_task_index < len(self.tasks) and not self.status.grasp_status[self.current_task_index]:
            if self.status.nav_status[self.current_task_index]:
                task = self.tasks[self.current_task_index]
                rospy.loginfo(f"Executing grasp task: {task}")
                self.pub1.publish(self.plan_list)
                rospy.loginfo(f"Pub 1: {self.plan_list.actions}")
                image = camera()
                self.pub2.publish(image)
                rospy.loginfo('Pub 2: camera delivered!')
                rospy.wait_for_message("/image", camera, timeout=None)
                rospy.wait_for_message("/success", success, timeout=None)
                self.task_completed(task)
        else:
            rospy.loginfo("No more tasks to execute")

    def task_completed(self,task=None):
        ##这里根据task写你的grasp执行代码，要求执行成功才能继续执行下去
        self.status.grasp_status = [True if i == self.current_task_index else False for i in range(len(self.tasks))]  #赋值当前子任务index下的状态值为true
        # print(self.status_msg.status)
        self.grasp_pub.publish(self.status)  #发布状态值，给规划模块接收
        print("-------任务执行结束-------")

    @staticmethod
    def run_command_with_input(command, input_text):
        child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
        child.logfile = open('/tmp/pexpect.log', 'w')  # 用于调试
        try:
            child.expect('Please enter the object you want: ')
            child.sendline(input_text)
            child.expect(pexpect.EOF, timeout=120)
            stdout = child.before
            stderr = child.after  # 捕获 EOF 之后的输出
        except pexpect.EOF:
            stdout = child.before
            stderr = ''  # 处理 EOF 错误
        finally:
            child.logfile.close()
        return stdout, stderr


if __name__ == '__main__':
    rospy.init_node('grasping_node')
    GraspingNode()
    rospy.spin()
