import rospy
import cv2
import numpy as np
import time
import os
import pexpect
import json
from grasp_topic.msg import plan, camera, pose


plan_received = False
image_received = False
save_path = ''

# 创建一个节点
rospy.init_node('grasp_3090')

def run_command_with_input(command, input_text):
    child = pexpect.spawn('/bin/bash', ['-c', command], encoding='utf-8')
    child.logfile = open('/tmp/pexpect.log', 'w')  # 用于调试
    try:
        child.expect('Please enter the object you want: ')
        child.sendline(input_text)
        child.expect(pexpect.EOF)
        stdout = child.before
        stderr = child.after  # 捕获 EOF 之后的输出
    except pexpect.EOF:
        stdout = child.before
        stderr = ''  # 处理 EOF 错误
    finally:
        
        child.logfile.close()
    return stdout, stderr

# 定义回调函数
def callback1(plan):
    global plan_received
    rospy.loginfo('Sub 1: plan received - %s', plan.actions)
    plan_received = True

def callback3(image):
    global image_received
    global save_path
    color = np.array(list(image.color), dtype=np.uint8).reshape(image.size)
    depth_npy = np.array(list(image.depth), dtype=np.uint16).reshape((image.size[0], image.size[1]))
    par_path = '/home/user/PTY/Polaris/SAR-Net++/pipeline'
    current_time = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime())
    save_path = os.path.join(par_path, "out", current_time)
    record_timestamps_path = os.path.join(par_path, "out", "record_timestamps.txt")
    with open(record_timestamps_path, "a") as file:
        file.write(current_time + "\n")
    os.mkdir(save_path)
    os.mkdir(os.path.join(save_path, "color"))
    os.mkdir(os.path.join(save_path, "depth"))
    cv2.imwrite(os.path.join(save_path, "color", "0.png"), color)
    np.save(os.path.join(save_path, "depth", "0"), depth_npy)
    cv2.imwrite(os.path.join(save_path, "depth", "0.png"), depth_npy)
    rospy.loginfo('Sub 3: image received & saved!')
    image_received = True


# 创建订阅者对象
sub1 = rospy.Subscriber('/plan', plan, callback1)
sub3 = rospy.Subscriber('/image', camera, callback3)

# 创建发布者对象
pub1 = rospy.Publisher('/plan', plan, queue_size=10)
pub2 = rospy.Publisher('/camera', camera, queue_size=10)
pub4 = rospy.Publisher('/pose', pose, queue_size=10)


# 发布数据
while not rospy.is_shutdown():
    plan0 = plan()
    pub1.publish(plan0)
    if plan_received:
        image = camera()
        pub2.publish(image)
        rospy.loginfo('Pub 2: camera delivered!')
    if image_received and not os.path.exists(os.path.join(save_path, "grounded_light_hqsam")):
        command = """
            source ~/miniconda3/etc/profile.d/conda.sh && 
            conda activate polaris && 
            cd /home/user/PTY/Polaris/SAR-Net++/pipeline/EfficientSAM && 
            python grounded_light_hqsam.py && 
            cd ../SAR-Net/ && 
            python inference.py --config ./config_evaluate/nocs_real_mrcnn_mask.txt
        """
        input_text = 'pick up the white bottle'
        stdout, stderr = run_command_with_input(command, input_text=input_text)
        print("Standard Output:", stdout)
        # print("Standard Error:", stderr)
    if os.path.exists(os.path.join(save_path, "sar-pose.json")):
        with open(os.path.join(save_path, "sar-pose.json"), 'r') as file:
            data = json.load(file)
        sar_pose = np.array(data['pose'][0], dtype=np.float32).flatten().tolist()
        pub4.publish(pose(sar_pose))
        rospy.loginfo('Pub 4: pose delivered!')
    rospy.sleep(2)
