#!/usr/bin/env python
#coding=utf-8
import rospy
#倒入自定义的数据类型
from grasp_topic.msg import camera_pose

def talker():
    pub = rospy.Publisher('grasp_topic', camera_pose, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(1)
    x = 3
    rospy.loginfo('Talker: x = %d', x)
    y = 0
    while not rospy.is_shutdown():
        pub.publish(camera_pose(x, y))
        y = y + 1
        rate.sleep()

if __name__ == '__main__':
    talker()
